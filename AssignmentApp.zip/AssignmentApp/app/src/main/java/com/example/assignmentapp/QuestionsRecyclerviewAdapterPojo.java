package com.example.assignmentapp;

import org.json.JSONArray;

public class QuestionsRecyclerviewAdapterPojo
{
    private String question,answer;
    private JSONArray options;

    public String getAnswer() {
        return answer;
    }

    public void setAnswer(String answer) {
        this.answer = answer;
    }

    public String getQuestion() {
        return question;
    }

    public void setQuestion(String question) {
        this.question = question;
    }

    public JSONArray getOptions() {
        return options;
    }

    public void setOptions(JSONArray options) {
        this.options = options;
    }
}
