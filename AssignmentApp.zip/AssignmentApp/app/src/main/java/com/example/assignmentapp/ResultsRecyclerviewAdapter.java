package com.example.assignmentapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class ResultsRecyclerviewAdapter extends RecyclerView.Adapter<ResultsRecyclerviewAdapter.MyViewHolder>
{
    private Context context;
    private ArrayList<String> questionsList,answersList,resultsList;
    static class MyViewHolder extends RecyclerView.ViewHolder
    {
        TextView questionTextview,resultTextview;
        ImageView imageView;
        MyViewHolder(View view)
        {
            super(view);

            imageView = view.findViewById(R.id.imageView);
            resultTextview = view.findViewById(R.id.resultTextview);
            questionTextview = view.findViewById(R.id.questionTextview);
        }
    }


    ResultsRecyclerviewAdapter(Context context, ArrayList<String> questionsList, ArrayList<String> answersList, ArrayList<String> resultsList)
    {
        this.context = context;
        this.answersList =answersList;
        this.resultsList = resultsList;
        this.questionsList = questionsList;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.results_recyclerview_lisitem, parent, false);
        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull final MyViewHolder holder, final int position)
    {
        holder.questionTextview.setText("Q) "+questionsList.get(position));
        holder.resultTextview.setText("A) "+resultsList.get(position));

        if (resultsList.get(position).equalsIgnoreCase(answersList.get(position)))
            holder.imageView.setImageResource(R.drawable.right);
        else
            holder.imageView.setImageResource(R.drawable.wrong);
    }

    @Override
    public int getItemCount() {
        return questionsList.size();
    }
}