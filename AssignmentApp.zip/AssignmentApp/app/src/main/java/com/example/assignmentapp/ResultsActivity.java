package com.example.assignmentapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;

public class ResultsActivity extends AppCompatActivity
{
    RecyclerView resultsRecyclerview;
    ArrayList<String> questionsList,answersList,resultsList;
    ResultsRecyclerviewAdapter resultsRecyclerviewAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_results);

        questionsList = new ArrayList<>();
        answersList = new ArrayList<>();
        resultsList = new ArrayList<>();

        Bundle bundle = getIntent().getExtras();
        if (bundle != null)
        {
            questionsList = bundle.getStringArrayList("questionsList");
            answersList = bundle.getStringArrayList("answersList");
            resultsList = bundle.getStringArrayList("resultsList");
        }

        resultsRecyclerview = findViewById(R.id.resultsRecyclerview);
        resultsRecyclerviewAdapter = new ResultsRecyclerviewAdapter(ResultsActivity.this,questionsList,answersList,resultsList);
        resultsRecyclerview.setLayoutManager(new LinearLayoutManager(ResultsActivity.this));
        resultsRecyclerview.setAdapter(resultsRecyclerviewAdapter);

    }
}
