package com.example.assignmentapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import org.json.JSONArray;
import org.json.JSONException;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class QuestionsRecyclerviewAdapter extends RecyclerView.Adapter<QuestionsRecyclerviewAdapter.MyViewHolder>
{
    private Context context;
    private ArrayList<String> answersList,resultsList;
    private List<QuestionsRecyclerviewAdapterPojo> questionsRecyclerviewAdapterPojoList;
    static class MyViewHolder extends RecyclerView.ViewHolder
    {
        RadioGroup radioGroup;
        TextView questionTextview;
        RadioButton button1,button2,button3,button4;

        MyViewHolder(View view)
        {
            super(view);

            button1 = view.findViewById(R.id.button1);
            button2 = view.findViewById(R.id.button2);
            button3 = view.findViewById(R.id.button3);
            button4 = view.findViewById(R.id.button4);
            radioGroup = view.findViewById(R.id.radioGroup);
            questionTextview = view.findViewById(R.id.questionTextview);
        }
    }


    QuestionsRecyclerviewAdapter(Context context, List<QuestionsRecyclerviewAdapterPojo> questionsRecyclerviewAdapterPojoList, ArrayList<String> answersList)
    {
        this.context = context;
        this.answersList = answersList;
        this.questionsRecyclerviewAdapterPojoList = questionsRecyclerviewAdapterPojoList;

        resultsList = new ArrayList<>();
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.questions_recyclerview_listitem, parent, false);
        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull final MyViewHolder holder, final int position)
    {
        QuestionsRecyclerviewAdapterPojo questionsRecyclerviewAdapterPojo = questionsRecyclerviewAdapterPojoList.get(position);

        final String answer = questionsRecyclerviewAdapterPojo.getAnswer();
        String question = questionsRecyclerviewAdapterPojo.getQuestion();
        JSONArray options = questionsRecyclerviewAdapterPojo.getOptions();

        holder.questionTextview.setText("Q) "+question);

        for (int i = 0; i < holder.radioGroup.getChildCount(); i++)
        {
            try
            {
                ((RadioButton) holder.radioGroup.getChildAt(i)).setText(options.getString(i));
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        holder.radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i)
            {
                RadioButton radioButton = radioGroup.findViewById(i);
                String selected = radioButton.getText().toString().trim();
                resultsList.add(selected);
            }
        });
    }

    ArrayList<String> updatedList()
    {
        return resultsList;
    }

    @Override
    public int getItemCount() {
        return questionsRecyclerviewAdapterPojoList.size();
    }
}
