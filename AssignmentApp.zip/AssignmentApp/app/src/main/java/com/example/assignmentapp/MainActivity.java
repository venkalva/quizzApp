package com.example.assignmentapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity
{
    Button submitAnswers;
    ArrayList<String> questionsList,answersList;
    RecyclerView questionsRecyclerview;
    QuestionsRecyclerviewAdapter questionsRecyclerviewAdapter;
    QuestionsRecyclerviewAdapterPojo questionsRecyclerviewAdapterPojo;
    List<QuestionsRecyclerviewAdapterPojo> questionsRecyclerviewAdapterPojoList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        questionsRecyclerviewAdapterPojoList = new ArrayList<>();
        submitAnswers = findViewById(R.id.submitAnswers);
        questionsRecyclerview = findViewById(R.id.questionsRecyclerview);

        try
        {
            questionsList = new ArrayList<>();
            answersList = new ArrayList<>();
            JSONObject  jsonObject = new JSONObject(loadJSONFromAsset());

            if (jsonObject.has("questions") && !jsonObject.isNull("questions"))
            {
                JSONArray jsonArray = jsonObject.getJSONArray("questions");

                for (int j=0; j<jsonArray.length(); j++)
                {
                    String question,answer;
                    JSONArray optionsArray;
                    JSONObject questionObj = jsonArray.getJSONObject(j);

                    if (questionObj.has("question") && !questionObj.isNull("question"))
                        question = questionObj.getString("question");
                    else
                        question = "";
                    questionsList.add(question);

                    if (questionObj.has("answer") && !questionObj.isNull("answer"))
                        answer = questionObj.getString("answer");
                    else
                        answer = "";
                    answersList.add(answer);

                    if (questionObj.has("options") && !questionObj.isNull("options"))
                        optionsArray = questionObj.getJSONArray("options");
                    else
                        optionsArray = new JSONArray();

                    questionsRecyclerviewAdapterPojo = new QuestionsRecyclerviewAdapterPojo();
                    questionsRecyclerviewAdapterPojo.setAnswer(answer);
                    questionsRecyclerviewAdapterPojo.setQuestion(question);
                    questionsRecyclerviewAdapterPojo.setOptions(optionsArray);
                    questionsRecyclerviewAdapterPojoList.add(questionsRecyclerviewAdapterPojo);
                }

                questionsRecyclerviewAdapter = new QuestionsRecyclerviewAdapter(MainActivity.this,questionsRecyclerviewAdapterPojoList,answersList);
                questionsRecyclerview.setLayoutManager(new LinearLayoutManager(MainActivity.this));
                questionsRecyclerview.setAdapter(questionsRecyclerviewAdapter);
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }


        submitAnswers.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                ArrayList<String> resultsList = questionsRecyclerviewAdapter.updatedList();
                if (questionsRecyclerviewAdapterPojoList.size() == resultsList.size())
                {
                    Intent intent = new Intent(MainActivity.this,ResultsActivity.class);
                    intent.putStringArrayListExtra("questionsList",questionsList);
                    intent.putStringArrayListExtra("answersList",answersList);
                    intent.putStringArrayListExtra("resultsList",resultsList);
                    startActivity(intent);
                }else
                {
                    Toast.makeText(MainActivity.this, "Please Fill All Answers", Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    public String loadJSONFromAsset() {
        String json = null;
        try {
            InputStream is = getAssets().open("assignmentapp-ceb5e-export.json");
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();
            json = new String(buffer, "UTF-8");
        } catch (IOException ex)
        {
            ex.printStackTrace();
            return null;
        }
        return json;
    }
}
